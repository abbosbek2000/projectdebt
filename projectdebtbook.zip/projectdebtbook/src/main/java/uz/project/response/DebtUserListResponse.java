package uz.project.response;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;
@Data
@AllArgsConstructor
@NoArgsConstructor
public class DebtUserListResponse {
    private String id;
    private String name;
    private Double debtAmount;
    private String phoneNumber;
    private Integer limitMonth;
    private String city_id;
    private String city_name;
    private String region_name;
}
