package uz.project.service;

import org.springframework.stereotype.Service;
import uz.project.controller.base.BaseController;
import uz.project.model.entity.city.City;
import uz.project.model.entity.debtUser.DebtUsers;
import uz.project.model.entity.response.BaseResponse;
import uz.project.payload.DebtUsersDto;
import uz.project.repository.CityRepository;
import uz.project.repository.DebtUserRepository;
import uz.project.response.DebtUserListResponse;

import java.util.ArrayList;
import java.util.List;
import java.util.Optional;

@Service
public class DebtUserService implements BaseController {
    private final CityRepository cityRepository;
    private final DebtUserRepository debtUserRepository;

    public DebtUserService(CityRepository cityRepository, DebtUserRepository debtUserRepository) {
        this.cityRepository = cityRepository;
        this.debtUserRepository = debtUserRepository;
    }

    public BaseResponse addDebt(DebtUsersDto debtUsersDto) {
        DebtUsers debtUsers = new DebtUsers();
        debtUsers.setName(debtUsersDto.getName());
        debtUsers.setDebtAmount(debtUsersDto.getDebtAmount());
        debtUsers.setLimitMonth(debtUsersDto.getLimitMonth());
        debtUsers.setPhoneNumber(debtUsersDto.getPhoneNumber());
        boolean existsByPhoneNumber = debtUserRepository.existsByPhoneNumber(debtUsersDto.getPhoneNumber());
        if (!existsByPhoneNumber) {
            Optional<City> optionalCity = cityRepository.findById(debtUsersDto.getCity_id());
            if (optionalCity.isPresent()) {
                City city = optionalCity.get();
                debtUsers.setCity(city);
                debtUserRepository.save(debtUsers);
            }
            return SUCCESS;
        }
        return ERROR;
    }

    public List<DebtUserListResponse> getDebtList() {
        List<DebtUserListResponse> debtUserListResponses = new ArrayList<>();
        DebtUserListResponse debtUserListResponse = new DebtUserListResponse();
        List<DebtUsers> list = debtUserRepository.findAll();
        list.forEach(debtUsers -> {
            debtUserListResponse.setId(debtUsers.getId().toString());
            debtUserListResponse.setName(debtUsers.getName());
            debtUserListResponse.setRegion_name(debtUsers.getCity().getRegion().getName());
            debtUserListResponse.setCity_name(debtUsers.getCity().getName());
            debtUserListResponse.setCity_id(debtUsers.getCity().getId().toString());
            debtUserListResponse.setDebtAmount(debtUsers.getDebtAmount());
            debtUserListResponse.setPhoneNumber(debtUsers.getPhoneNumber());
            debtUserListResponse.setLimitMonth(debtUsers.getLimitMonth());
            debtUserListResponses.add(debtUserListResponse);
        });
        return debtUserListResponses;
    }


}
