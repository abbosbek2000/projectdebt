package uz.project.repository;

import org.springframework.data.jpa.repository.JpaRepository;
import uz.project.model.entity.region.Region;

import javax.validation.constraints.NotNull;
import java.util.UUID;

public interface RegionRepository extends JpaRepository<Region, UUID> {
    boolean existsByName(@NotNull(message = "name not found ") String name);
}
