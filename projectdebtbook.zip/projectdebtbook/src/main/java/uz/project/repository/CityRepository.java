package uz.project.repository;

import org.springframework.data.jpa.repository.JpaRepository;
import uz.project.model.entity.city.City;

import java.util.UUID;

public interface CityRepository extends JpaRepository<City, UUID> {

}
