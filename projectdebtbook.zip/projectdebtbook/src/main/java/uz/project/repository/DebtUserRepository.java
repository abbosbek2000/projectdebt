package uz.project.repository;

import org.springframework.data.jpa.repository.JpaRepository;
import uz.project.model.entity.debtUser.DebtUsers;

import java.util.UUID;

public interface DebtUserRepository extends JpaRepository<DebtUsers, UUID> {
    boolean existsByPhoneNumber(String phoneNumber);
}
