package uz.project.controller;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpEntity;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.validation.FieldError;
import org.springframework.web.bind.MethodArgumentNotValidException;
import org.springframework.web.bind.annotation.*;
import uz.project.controller.base.BaseController;
import uz.project.model.entity.response.BaseResponse;
import uz.project.payload.DebtUsersDto;
import uz.project.repository.CityRepository;
import uz.project.repository.DebtUserRepository;
import uz.project.response.DebtUserListResponse;
import uz.project.service.DebtUserService;

import javax.validation.Valid;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

@RestController
@RequestMapping("/api/debt")
public class DebtUserController implements BaseController {
    private final CityRepository cityRepository;
    private final DebtUserRepository debtUserRepository;
    private final DebtUserService debtUserService;

    @Autowired
    public DebtUserController(CityRepository cityRepository, DebtUserRepository debtUserRepository, DebtUserService debtUserService) {
        this.cityRepository = cityRepository;
        this.debtUserRepository = debtUserRepository;
        this.debtUserService = debtUserService;
    }

    @PostMapping("/add")
    public HttpEntity<?> addDebtUsers(
            @Valid @RequestBody DebtUsersDto debtUsersDto)
    {
        BaseResponse baseResponse = debtUserService.addDebt(debtUsersDto);
       if(baseResponse.isSuccess())
           return ResponseEntity.status(200).body("debt user muvaffaqiyatli qo'shildi");
       else
           return ResponseEntity.status(400).body("user qo'shilmadi");
    }

    @GetMapping("/list")
    public List<DebtUserListResponse> get() {
        List<DebtUserListResponse> debtList = debtUserService.getDebtList();
        return debtList;
    }

    @ResponseStatus(HttpStatus.BAD_REQUEST)
    @ExceptionHandler(MethodArgumentNotValidException.class)
    public Map<String, String> validException(MethodArgumentNotValidException ex) {
        Map<String, String> errors = new HashMap<>();
        ex.getBindingResult().getAllErrors().forEach((error) -> {
            String fileName = ((FieldError) error).getField();
            String errorMessage = error.getDefaultMessage();
            errors.put(fileName, errorMessage);
        });
        return errors;
    }
}
