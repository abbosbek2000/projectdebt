package uz.project.controller.base;


import uz.project.model.entity.response.BaseResponse;

public interface BaseController {

    BaseResponse SUCCESS = new BaseResponse("success", 1, true);
    BaseResponse ERROR = new BaseResponse("error", -1, false);
}
