package uz.project.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpEntity;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;
import uz.project.model.entity.region.Region;
import uz.project.model.entity.response.BaseResponse;
import uz.project.service.RegionService;
import java.util.List;

@RestController
@RequestMapping("/api/region")
public class RegionController {
    @Autowired
    RegionService regionService;

    @PostMapping("/add")
    public HttpEntity<BaseResponse> addRegion(
            @RequestBody Region region)
    {
            BaseResponse baseResponse = regionService.addRegion(region);
            return baseResponse.isSuccess() ? ResponseEntity.status(200).body(baseResponse):
                    ResponseEntity.status(400).body(baseResponse);
    }

    @GetMapping("/list")
    public List<Region> getRegionList() {
        return regionService.getRegionList();
    }
}
