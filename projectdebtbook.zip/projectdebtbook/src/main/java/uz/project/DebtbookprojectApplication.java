package uz.project;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;


@SpringBootApplication
public class DebtbookprojectApplication {


    public static void main(String[] args)   {
        SpringApplication.run(DebtbookprojectApplication.class, args);
    }

}
